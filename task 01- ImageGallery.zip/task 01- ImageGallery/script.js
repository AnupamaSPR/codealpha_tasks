function showSection(sectionId) {
    document.querySelectorAll('.gallery-section').forEach(section => {
        section.classList.add('hidden');
    });
    document.getElementById(sectionId).classList.remove('hidden');

    document.querySelectorAll('.tab-button').forEach(button => {
        button.classList.remove('active');
    });

    if (sectionId === "pictures") {
        document.querySelector('.tab-button:nth-child(1)').classList.add('active');
    } else {
        document.querySelector('.tab-button:nth-child(2)').classList.add('active');
    }
}

function showImages(album) {
    const imageGrid = document.getElementById("image-grid");
    imageGrid.innerHTML = "";

    let images = [];
    if (album === "vacation") {
        images = ["image3.jpeg","image2.jpeg", "image4.jpeg","image1.jpeg","image10.jpeg", "image11.jpeg","image12.jpeg", "image13.jpeg", "image14.jpeg"];

    } else if (album === "family") {
        images = ["image5.jpeg", "image6.jpeg","image7.jpeg"];
    }

    images.forEach(imgSrc => {
        const img = document.createElement("img");
        img.src = imgSrc;
        img.alt = "Image";
        img.onclick = () => openImage(imgSrc);
        imageGrid.appendChild(img);
    });

    showSection('album-images');
}

function openImage(src) {
    document.getElementById("lightbox-img").src = src;
    document.getElementById("lightbox").style.display = "flex";
}

function closeImage() {
    document.getElementById("lightbox").style.display = "none";
}
